/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domein;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 *
 * @author diete
 */
public class Spel {
    private Speler spelerAanDeBeurt;
    private int aantalSpelers;
    private int beurt;
    private Stapel schatKaarten;
    private Stapel kerkerKaarten;
    private Speler speler;
    private Speler eersteSpeler;
    private ResourceBundle labels;
    List<Speler> spelers = new ArrayList<>();
    
    public Spel(int aantalSpelers, Stapel kerkerKaarten, Stapel schatKaarten, ResourceBundle labels) throws SQLException{
        controleerAantalSpelers(aantalSpelers);
        setAantalSpelers(aantalSpelers);
        this.kerkerKaarten = kerkerKaarten;
        this.schatKaarten = schatKaarten;
        this.labels = labels;
        
    }

    private void setAantalSpelers(int aantalSpelers) {
        this.aantalSpelers = aantalSpelers;
    }
    
    public void voegSpelerToe(String naam, String geslacht){
        controleerNaamUniek(naam);
        speler = new Speler(naam, geslacht);
        spelers.add(speler);
        
        speler.trekKaart(2, schatKaarten);
        speler.trekKaart(2, kerkerKaarten);
    }   
    
    private void controleerAantalSpelers(int aantalSpelers){
        if(aantalSpelers < 3 || aantalSpelers > 6){
            throw new IllegalArgumentException("Aantal spelers moet tussen 3 en 6 liggen!");
        }
    }
    
    public String toonOverzichtSpelers(){
       String output = "";
        for (Speler speler : spelers) {
            output += String.format("%s\n", speler.toString());
        }
        return output;
    }
    
    public void eersteSpeler(){
        eersteSpeler = bepaalEersteSpeler();
        ordenSpelers();
    }
    
    public Speler bepaalEersteSpeler() {
        Speler eersteSpeler;
        eersteSpeler = spelers.get(0);
        for (Speler speler : spelers) {
            if(speler.getNaam().length() < eersteSpeler.getNaam().length()){
                eersteSpeler = speler;              
            }else if(speler.getNaam().length() == eersteSpeler.getNaam().length()) {
                    if(speler.getNaam().compareToIgnoreCase(eersteSpeler.getNaam()) > 0){
                        eersteSpeler = speler;                        
                    }
            }
        }
        this.eersteSpeler = eersteSpeler;
        return eersteSpeler;
    }
    
    public void ordenSpelers(){
        List<Speler> toRemove = new ArrayList<Speler>();
        for (Speler speler : spelers) {
            if(speler.getNaam().equals(eersteSpeler.getNaam())){
                toRemove.add(speler);
            }
        }
        spelers.removeAll(toRemove);
        spelers.add(0, eersteSpeler);
    }
    
    public void controleerNaamUniek(String naam) {
        for (Speler speler : spelers) {
            if (naam.toLowerCase().equals(speler.getNaam().toLowerCase())) {
                throw new IllegalArgumentException(labels.getString("exceptionUniekeNaam"));
            }
        }
    }

    public Speler getEersteSpeler() {
        return eersteSpeler;
    }
    
    public String overzichtHandSpelers(){
        String overzichtHandSpelers = "";
        
        for (Speler speler : spelers) {
            overzichtHandSpelers += speler.toonHand() + "\n";
        }
        
        return overzichtHandSpelers;
    }
    
    public String toonMenu() {
        return String.format("Kies uit het menu:\n"
                + "1) Speel beurt.\n"
                + "2) Spel opslaan.\n"
                + "3) Spel afsluiten.\n");
    }
    
    public void keuzeMenu(int keuze, Speler spelerAanDeBeurt) {
        switch (keuze) {
            case 1:
                speelBeurt(spelerAanDeBeurt);
                beurt++;
                break;
            case 2:
                slaSpelOp();
                ++beurt;
                break;
            case 3:
                sluitSpelAf();
                break;
            default:
                throw new IllegalArgumentException("Kies een juiste optie! (1, 2 of 3)");
                
        }
    }
    
    public void speelBeurt(Speler spelerAanDeBeurt) {
        System.out.println(toonOverzichtSpel());
        promptEnterKey();
    }
    

    
    public void slaSpelOp(){
        System.out.println("Het spel wordt opgeslaan... (nog niet echt)\n");
    }
    
    public void sluitSpelAf(){
        System.out.println("Het spel wordt afgesloten...");
        System.exit(0);
    }
    
    public boolean isAfgelopen(){
        
        for (Speler speler : spelers) {
            if (speler.getLevel() == 10)
                return true;
        }
        return false;   
    }
    
    public void bepaalSpelerAanDeBeurt() {
        if (beurt == aantalSpelers)
            beurt = 0;
        spelerAanDeBeurt = spelers.get(beurt);           
    }
    
    public Speler getSpelerAanDeBeurt(){
        return spelerAanDeBeurt;
    }
    
    public String toonOverzichtSpel() {
        return String.format("------------------------------OVERZICHT SPEL------------------------------ \n\n"
                + "%s is aan de beurt!\n\n"
                + "%s", spelerAanDeBeurt.getNaam(), OverzichtSpelers());
    }
    
    public String OverzichtSpelers() {
        String overzichtSpelers = "";
        
        for (Speler speler : spelers) {
            overzichtSpelers += speler.overzichtSpeler() + "\n";
        }
        
        return overzichtSpelers;
    }
    
    public void promptEnterKey(){
        System.out.println("Press \"ENTER\" to continue...");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
}
    public void setLabel(ResourceBundle labels){
        this.labels = labels;
    }     
}
