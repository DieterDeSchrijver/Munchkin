/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domein;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 *
 * @author diete
 */
public class Speler {
    private int level;
    private String naam;
    private String geslacht;
    List<Kaart> hand = new ArrayList<>();

    public Speler(String naam, String geslacht){
        controleerNaam(naam);
        controleerGeslacht(geslacht);
        setGeslacht(geslacht);
        setLevel(1);
        setNaam(naam);
    }

    private void setGeslacht(String geslacht) {
        this.geslacht = geslacht;
    }

    private void setLevel(int level) {
        this.level = level;
    }

    private void setNaam(String naam) {
        this.naam = naam;
    }
    
    public void trekKaart(int aantal, Stapel stapel){
            for (int i = 0; i < aantal; i++) {
            Kaart kaart;
            kaart = stapel.trekKaart();
            voegKaartToeAanHand(kaart);
        }
    }
    
    public void voegKaartToeAanHand(Kaart kaart){
        hand.add(kaart);
    }
    
    private void controleerNaam(String naam){
        //minstens 6 tekens lang max 12
        if(naam.length() < 6 || naam.length() > 12){
            throw new IllegalArgumentException("Naam moet bestaan uit 6 en 12 karakters");
        }
           
        if(!Pattern.matches("[a-zA-Z]+", naam) && !naam.contains("_") && !naam.contains("-")){
            throw new IllegalArgumentException("De naam mag enkel de tekens a-z, A-Z, _ of - bevatten!");
        } 
    }
    private void controleerGeslacht(String geslacht){
        String geslachtKlein;
        geslachtKlein = geslacht.toLowerCase();
        if(!"man".equals(geslachtKlein) && !"vrouw".equals(geslachtKlein) && !"woman".equals(geslachtKlein) && !"homme".equals(geslachtKlein) && !"femme".equals(geslachtKlein)){
            throw new IllegalArgumentException("Geslacht kan enkel man of vrouw zijn!");
        }
    }
    
    @Override
    public String toString(){
        return String.format("%s, %s", naam, geslacht);
    }
    
    public String getNaam(){
        return naam;
    }
    
    public String toonHand(){
        String stringHand = "";
        for (Kaart kaart : hand) {
            stringHand += kaart.toString() + "\n";
        }
        return String.format("%s bezit volgende kaarten:\n\n"
                + "%s",naam,  stringHand);
    }
    
    public int getLevel(){
        return level;
    }
    
    public void speelBeurt() {
    }
    
    public String overzichtSpeler(){
        return String.format("----------- %s -----------\n"
                + "Level: %d\n"
                + "Geslacht: %s \n"
                + "------------------------------\n\n"
                + "%s \n", naam, level, geslacht, toonHand());
    }
}
