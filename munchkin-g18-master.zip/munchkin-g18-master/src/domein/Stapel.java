/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domein;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author diete
 */
public class Stapel {

    private List<Kaart> kaarten = new ArrayList<>();
    private String naam;

    public Stapel(String naam) {
        setNaam(naam);
    }

    private void setNaam(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void voegKaartToe(Kaart kaart) {
        kaarten.add(kaart);
    }

    public Kaart trekKaart() {
        Kaart kaart;
        kaart = kaarten.get(0);
        kaarten.remove(0);
        return kaart;
    }

    public void schudKaarten() {
        Collections.shuffle(kaarten);
    }

}
