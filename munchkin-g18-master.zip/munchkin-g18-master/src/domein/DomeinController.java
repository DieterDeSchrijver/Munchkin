/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domein;

import java.sql.SQLException;
import java.util.ResourceBundle;
import ui.Applicatie;

/**
 *
 * @author diete
 */
public class DomeinController {

    private Spel spel;
    private KaartRepository kaartRepo;
    private Stapel schatKaarten;
    private Stapel kerkerKaarten;
    private Applicatie ui;
    private int keuzeTaal;
    private ResourceBundle labels;

    public DomeinController() {
        ui = new Applicatie(this);
    }

    public void maakSpel(int aantalSpelers, ResourceBundle labels) throws SQLException{
        kaartRepo = new KaartRepository();
        kaartRepo.maakKaartenAan();
        voegKaartenToeAanStapels();
        spel = new Spel(aantalSpelers, schatKaarten, kerkerKaarten, labels);
        schudKaarten();
    }

    public void voegSpelerToe(String naam, String geslacht) {
        spel.voegSpelerToe(naam, geslacht);
    }

    public String toonOverzicht() {
        return spel.toonOverzichtSpelers();
    }
    
    public void speelSpel(){
        spel.eersteSpeler();
        ui.toonOverzicht(spel.toonOverzichtSpelers());
        do{
            spel.bepaalSpelerAanDeBeurt();
            spel.keuzeMenu(ui.maakKeuze(),spel.getSpelerAanDeBeurt());
        }while(!spel.isAfgelopen());
        
    }
    
    public String toonMenu() {
        return spel.toonMenu();
    }
    
    public void voegKaartenToeAanStapels() {
        kerkerKaarten = new Stapel("KerkerKaarten");
        schatKaarten = new Stapel("schatKaarten");
        for (Kaart kaart : kaartRepo.getKaarten()) {
            if(kaart instanceof KerkerKaart){
            kerkerKaarten.voegKaartToe(kaart);
        }else if (kaart instanceof SchatKaart){
            schatKaarten.voegKaartToe(kaart);
        }   
        }
    }
    
    private void schudKaarten(){
        schatKaarten.schudKaarten();
        kerkerKaarten.schudKaarten();
    }
    
    public String OverzichtHanden(){
        return spel.overzichtHandSpelers();
    }
    
    public String kiesTaal() {
        return String.format("1) Kies Nederlands\n"
                + "2) Choose English\n"
                + "3) Choisir le français\n");
    }
    
    public int getKeuzeTaal(){
        return keuzeTaal;
    }
    
    public void keuzeTaal(){
        keuzeTaal = ui.kiesTaal(kiesTaal());
    }
    
    public void setLabel(ResourceBundle labels) {
        this.labels = labels;
    }
}
