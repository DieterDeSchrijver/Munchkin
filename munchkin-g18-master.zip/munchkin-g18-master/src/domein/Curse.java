package domein;


public class Curse extends KerkerKaart {

    private String naam;
    private String omschrijving;
    private String specialEffect;

    public Curse(String naam, String omschrijving, String specialEffect) {
        super(naam);
        this.omschrijving = omschrijving;
        this.specialEffect = specialEffect;
    }
    
    @Override
    public String toString(){
        return String.format("%s\n"
                + "%s\n"
                + "%s\n", getNaam(), omschrijving, specialEffect);
    }
}
