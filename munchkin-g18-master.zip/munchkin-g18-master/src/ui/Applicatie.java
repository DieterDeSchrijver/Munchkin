/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import domein.DomeinController;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diete
 */
public class Applicatie {

    private final DomeinController dc;
    private Locale locale;
    Scanner sc = new Scanner(System.in);
    ResourceBundle labels;


    public Applicatie(DomeinController dc) {
        this.dc = dc;
        
    }

    public void start() {
        int aantalSpelers = 0;
        String geslacht;
        String naam;
        
        dc.keuzeTaal();
        instellenTaal(dc.getKeuzeTaal());
        
        labels = ResourceBundle.getBundle("i18n.MyBundle", locale);    
        
        System.out.println(labels.getString("welkomwoord"));
        System.out.println(labels.getString("aanmakenSpel"));

        
        while (aantalSpelers < 3 || aantalSpelers > 6) {
            try {
                System.out.println(labels.getString("vraagHoeveelSpelers"));
                aantalSpelers = sc.nextInt();
                dc.maakSpel(aantalSpelers, labels);
            } catch (IllegalArgumentException e) {
                System.err.println("");
                System.err.println(e.getMessage());
                sc.nextLine();
            } catch (InputMismatchException f) {
                System.err.println("");
                System.err.println(labels.getString("exceptionNumeriekeWaarde"));
                System.err.println("");
                sc.nextLine();
            } catch (SQLException ex) {
                Logger.getLogger(Applicatie.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        for (int i = 1; i <= aantalSpelers; i++) {

            System.out.println("");
            System.out.println(labels.getString("speler") + i);
            System.out.println(labels.getString("geefNaam"));
            naam = sc.next();
            System.out.println(labels.getString("geefGeslacht"));
            geslacht = sc.next();

            
            try {
                dc.voegSpelerToe(naam, geslacht);
            } catch (IllegalArgumentException e) {
                --i;
                System.err.println("");
                System.err.println(e.getMessage());
                sc.nextLine();

            }
        }

        System.out.println("");
        System.out.println(labels.getString("overzicht")+"\n");
        System.out.println(dc.toonOverzicht());
        System.out.println("");
        
        boolean speelSpelFlag = true;
        do{
            try{
                dc.speelSpel();
                speelSpelFlag = false;
            } catch (InputMismatchException e){
                System.err.println(labels.getString("exceptionNumeriekeWaarde"));
                System.err.println("");
            } catch (IllegalArgumentException e){
                System.err.println(e.getMessage());
                System.err.println("");
            }
        } while(speelSpelFlag);
        
    }
    
    public int maakKeuze() {
        sc = new Scanner(System.in);
        System.out.println(dc.toonMenu());
        return sc.nextInt();
    }
    
    public void toonOverzicht(String tekst){
        System.out.println("Volgorde spelers: \n");
        System.out.println(tekst);
    }
    
    public int kiesTaal(String tekst) {
        System.out.println(tekst);
        return sc.nextInt();       
    }
    
    public void instellenTaal(int keuze){
        switch (keuze) {
            case 1:
                {
                    locale = new Locale("");
                    break;
                }
            case 2:
                {
                    locale = new Locale("en");
                    break;
                }
            case 3:
                {
                    locale = new Locale("fr");
                    break;
                }
            default:
                break;
        }
    }

}
