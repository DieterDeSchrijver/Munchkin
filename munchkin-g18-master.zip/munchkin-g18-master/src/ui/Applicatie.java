/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import domein.DomeinController;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diete
 */
public class Applicatie {

    private final DomeinController dc;
    private Scanner sc;


    public Applicatie(DomeinController dc) {
        this.dc = dc;
    }

    public void start() {
        int aantalSpelers = 0;
        String geslacht;
        String naam;

        sc = new Scanner(System.in);
        System.out.println("Welkom bij Munchkin");
        System.out.println("Nieuw spel wordt aangemaakt...");

        // Blijft exceptionhandling herhalen zolang aantalSpelers niet correct is
        // Geeft message wel op de verkeerde plaats, moet nog aangepast worden
        while (aantalSpelers < 3 || aantalSpelers > 6) {
            try {
                System.out.println("Met hoeveel spelers wilt u spelen? (3-6)");
                aantalSpelers = sc.nextInt();
                dc.maakSpel(aantalSpelers);
            } catch (IllegalArgumentException e) {
                System.out.println("");
                System.err.println(e.getMessage());
                sc.nextLine();
            } catch (InputMismatchException f) {
                System.out.println("");
                System.err.println("Geef een numerieke waarde in");
                System.out.println("");
                sc.nextLine();
            } catch (SQLException ex) {
                Logger.getLogger(Applicatie.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        for (int i = 1; i <= aantalSpelers; i++) {

            System.out.println("");
            System.out.println("Speler" + i);
            System.out.println("Naam (tussen de 6 en 12 karakters): ");
            naam = sc.next();
            System.out.println("Geslacht (man of vrouw): ");
            geslacht = sc.next();

            // Blijft exceptionhandling herhalen zolang naam niet correct is
            // Geeft message wel op de verkeerde plaats, moet nog aangepast worden!
            try {
                dc.voegSpelerToe(naam, geslacht);
            } catch (IllegalArgumentException e) {
                --i;
                System.out.println("");
                System.err.println(e.getMessage());
                sc.nextLine();

            }
        }

        System.out.println("");
        System.out.println("Overzicht: \n");
        System.out.println(dc.toonOverzicht());

        System.out.println("");
        
        dc.speelSpel();
        
    }
    
    public int maakKeuze() {
        sc = new Scanner(System.in);
        System.out.println(dc.toonMenu());
        return sc.nextInt();
    }
    
    public void toonOverzicht(String tekst){
        System.out.println("Volgorde spelers: \n");
        System.out.println(tekst);
    }

}
