package persistentie;

public class Connectie {
  public static final String JDBC_URL = "jdbc:mysql://ID222177_g18.db.webhosting.be?serverTimezone=UTC&useLegacyDatetimeCode=false&user=ID222177_g18&password=jodifKi2";  
}
