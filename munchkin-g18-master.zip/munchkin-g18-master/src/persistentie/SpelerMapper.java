package persistentie;

public class SpelerMapper {
    
}
